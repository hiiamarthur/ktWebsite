import Block from '/components/Common/Element/Block'
// import { useStore } from '/store'

export default function Home() {
  return (
    <Block>Home</Block>
  )
}
