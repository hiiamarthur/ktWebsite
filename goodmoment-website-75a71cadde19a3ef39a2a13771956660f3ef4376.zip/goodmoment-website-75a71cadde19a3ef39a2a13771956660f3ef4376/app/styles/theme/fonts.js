export default {
  roboto: 'Roboto, sans-serif',
}
